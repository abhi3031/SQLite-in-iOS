//
//  dbclass.swift
//  almo
//
//  Created by TOPS on 7/23/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class dbclass: NSObject {

    
    func dml(query:String) -> Bool {
        
        var status:Bool = true;
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] ;
        
        
        let fullpath = path.appending("/mydb.db");
        
        print(fullpath);
   
        var dbname :OpaquePointer? = nil;
        
        
        if sqlite3_open(fullpath, &dbname) == SQLITE_OK {
            
            var stmat: OpaquePointer? = nil
            
            if sqlite3_prepare_v2(dbname, query, -1, &stmat, nil) == SQLITE_OK {
                
                sqlite3_step(stmat);
                
                status = true;
                
            }
            
            sqlite3_finalize(stmat);
            
            
        }
        sqlite3_close(dbname);
        
        return status;
        
        
        
        
    }
    func getdata(query:String) -> [Any] {
        
        var arr:[Any] = [];
        
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] ;
        
        
        let fullpath = path.appending("/mydb.db");
        
        print(fullpath);
        
        var dbname :OpaquePointer? = nil;
        
        
        if sqlite3_open(fullpath, &dbname) == SQLITE_OK {
            
            var stmat: OpaquePointer? = nil
            
            if sqlite3_prepare_v2(dbname, query, -1, &stmat, nil) == SQLITE_OK {
                
                while sqlite3_step(stmat) == SQLITE_ROW {
                    var brr:[String] = [];
                    
                    
        let emp_id = String(cString: sqlite3_column_text(stmat, 0));
        let emp_name = String(cString: sqlite3_column_text(stmat, 1));
        let emp_add = String(cString: sqlite3_column_text(stmat, 2));
        
                    brr.append(emp_id);
                    brr.append(emp_name);
                    brr.append(emp_add);
                    
                    
                    
                    arr.append(brr);
                    
                    
                }
                
                
            }
            
            sqlite3_finalize(stmat);
            
            
        }
        sqlite3_close(dbname);
        
        return arr;
        

        
    }
}
