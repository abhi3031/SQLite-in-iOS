//
//  ViewController.swift
//  almo
//
//  Created by TOPS on 7/23/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txt1: UITextField!
    
    @IBOutlet weak var txt2: UITextField!
    
    @IBOutlet weak var txt3: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let db = dbclass();
        var arr = db.getdata(query: "select * from tblemp");
        print(arr);
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func btnclick(_ sender: Any) {
        
        let dbtest = dbclass();
        let query = "insert into tblemp(emp_id,emp_name,emp_add)values('\(txt1.text!)','\(txt2.text!)','\(txt3.text!)')";
        
        let st = dbtest.dml(query: query);
        
        if st == true
        {
            print("record inserted ..");
        }
        else
        {
            print("not inserted ..");
            
        }
     
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

